In "Compiled Class Files" there are class files that, if you wanted to, you could run from the command line.
In "Example Jarfile" there is a self-contained jarfile that works with a double-click on Windows. (Linux/mac: java -jar <drag in jar file>)
In "Source Code" There is the source code for both files: MainClass and PrimeThread. They are stored as both .java files and .txt files (in case you can't open the .java file).
If you have any questions at all, feel free to ask on the video for Tutorial 16!